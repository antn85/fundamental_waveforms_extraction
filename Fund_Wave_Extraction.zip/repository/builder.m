%builder



F0 = [piecesF0{:}];

H1 = [piecesH1{:}];

H2 = [piecesH2{:}];

H3 = [piecesH3{:}];

H4 = [piecesH4{:}];

