%builder



F0 = [piecesF0{:}];

H1 = [piecesH1{:}];

H2 = [piecesH2{:}];

H3 = [piecesH3{:}];

H4 = [piecesH4{:}];


%versions aligned to original speech file and time vector

F0aligned = [startPiece',F0,finalPiece'];

H1aligned = [startPiece',H1,finalPiece'];

H2aligned = [startPiece',H2,finalPiece'];

H3aligned = [startPiece',H3,finalPiece'];

H4aligned = [startPiece',H4,finalPiece'];


timealigned = 0:(1/Fs):((size(F0aligned,2)/Fs)-(1/Fs));  % (time vector)



