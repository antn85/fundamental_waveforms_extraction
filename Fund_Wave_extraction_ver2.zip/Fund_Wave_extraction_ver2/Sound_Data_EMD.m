%% read audio file

[y,SoundFs] = audioread(speechfile);

%% get rid of digital zeros at beginning and end of file. Only channel 1 is analysed (mono)...
... y must be coloumn vector

X = y(:,1);

% resampling
X = resample (X,8820,SoundFs); %resampling audio at around 8kHz
Fs = SoundFs/(SoundFs/8820);

begin = find(X,1,'first');
last = find(X,1,'last');

startPiece = X(1:begin-1);
finalPiece = X(last+1:end);

X = X(begin:last);

n = size(X,1);
t = n/Fs;       % time
h = t/n;       % step size
D = 0:h:t-h;    % domain (time vector)

clear times
clear begin last
