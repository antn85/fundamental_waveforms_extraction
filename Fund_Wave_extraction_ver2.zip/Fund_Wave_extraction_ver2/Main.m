%
% This is a working (early) version of the code written for the pubblication
% "The human auditory brainstem response to running speech 
%  reveals a subcortical mechanism for selective attention"
%
% by Antonio Elia Forte, Octave Etard and Tobias Reichenbach.
%
% For later and cleaner versions please visit: https://github.com/antn85/fundamental_waveforms_extraction
%
% This code performs the F0 (and higher harmonics) waveform extraction from
% continuous speech using EMD. An alighed version of the F0 (F0aligned) 
% to the original audio file and corresponding time array (timealigned) is also output.
% Just run Main.m and try it on Odin.wav (included).

%%
clear all
close all

%% make folder to save waveforms
folderName = 'Waveforms';
mkdir([folderName]);
SavePath = char(fullfile(folderName));

%% load speech file (audio file (e.g. .wav), Fs = 44100). There is a demo file for you to try (odin)
fileName = 'odin.wav';
speechfile = char(fullfile(fileName));

%% read audio file and filter it
Sound_Data_EMD;
X = Data_Filtering_1500HzLowPass_8kHzFs(X);
Filt_Delay_Comp;

%% get rig of silent parts
envelope_thresh;

%% calculate autocorrelation
autocorrelation;

%% analyser: split file in pieces and get the waveforms
splitter;
analizer;

%% builder: build the final waveform
builder;

%% plot filtered sound file, fundamental waveform and first harmonic (H1) waveform
figure;
plot(TotD, TotXenv, 'r'); 
hold on;
plot(TotD, F0, 'b');
plot(TotD, H1, 'g');
% plot(TotD, H2);
% plot(TotD, H3);
% plot(TotD, H4);
legend('Speech','F0','H1');
xlabel('Time (s)');
ylabel('Amplitude');

%% plot original sound file and fundamental waveform
figure;
soundD = 0:(1/SoundFs):((size(y,1)/SoundFs)-(1/SoundFs));
plot(soundD, y, 'r'); 
hold on;
plot(timealigned, F0aligned, 'b');
% plot(TotD, H2);
% plot(TotD, H3);
% plot(TotD, H4);
legend('Original Speech','F0aligned');
xlabel('Time (s)');
ylabel('Amplitude');

%% save F0 etc...
savename = 'F0';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'F0');
clear savename

savename = 'H1';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H1');
clear savename

savename = 'H2';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H2');
clear savename

savename = 'H3';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H3');
clear savename

savename = 'H4';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H4');
clear savename

%% save F0aligned etc...
savename = 'F0aligned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'F0aligned');
clear savename

savename = 'H1aligned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H1aligned');
clear savename

savename = 'H2aligned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H2aligned');
clear savename

savename = 'H3aligned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H3aligned');
clear savename

savename = 'H4aligned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'H4aligned');
clear savename

savename = 'timealigned';
fullFileName = fullfile(SavePath(1,:), savename);
save (fullFileName, 'timealigned');
clear savename
